1, Training and testing file have the same format, each line contains the following:
sentence1 \tab sentence2 \tab (n,6) \tab url

2, For each sentence pair, there are 6 Amazon Mechanical Turk workers annotating it. 1 representa paraphrase and 0 represents non-paraphrase. So totally n out 6 workers think the pair is paraphrase. If n<=2, we treat them as non-paraphrase; if n>=4, we treat them as paraphrase; if n==3, we discard them.

3, After discarding n==3, we can get 42200 for training and 9324 for testing.